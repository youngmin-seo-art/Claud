/*
 * 겨드랑이 전용 이온영동기기 프로토타입 펌웨어
 * 대상: ESP32 DevKit
 *
 * 기능:
 *  - 정전류 목표값 설정 (DAC 출력 -> 아날로그 정전류 회로)
 *  - 전류 모니터링 (ADC로 션트 저항 전압 측정)
 *  - 램프업/램프다운 (급격한 전류 변화 방지)
 *  - 임피던스 계산 및 이벤트 트리거 기반 극성 반전
 *    (고정 주기 반전이 아님 — 특허 회피 설계 포인트)
 *  - 다중 안전 차단: 소프트웨어 상한, 개방회로(패드 탈락) 감지, 세션 타이머
 *  - 하드웨어 비교기 기반 독립 과전류 차단은 별도 회로에서 처리되며
 *    이 펌웨어는 소프트웨어 레벨의 2차 방어선 역할을 합니다.
 *
 * ⚠️ 주의: 이 코드는 프로토타입 실험용입니다.
 *          인체에 사용하기 전 반드시 저항 부하로 충분히 검증하십시오.
 */

// ===================== 핀 설정 =====================
const int PIN_DAC_SETPOINT   = 25;   // DAC 출력 -> 정전류 회로 기준전압
const int PIN_ADC_CURRENT    = 34;   // 션트 저항 전압(계측증폭 후) 측정
const int PIN_HBRIDGE_IN1    = 26;   // H-브리지 방향 제어 1
const int PIN_HBRIDGE_IN2    = 27;   // H-브리지 방향 제어 2
const int PIN_ENABLE_OUTPUT  = 14;   // 출력 인에이블 (안전 차단용 MOSFET/릴레이 게이트)
const int PIN_STATUS_LED     = 2;

// ===================== 안전 파라미터 =====================
const float MAX_CURRENT_MA      = 15.0;   // 소프트웨어 상한 (하드웨어 상한은 회로에서 별도 설정, 예: 18~20mA)
const float START_CURRENT_MA    = 0.5;    // 시작 전류
const float RAMP_STEP_MA        = 0.2;    // 램프 단계당 증가량
const unsigned long RAMP_INTERVAL_MS   = 500;   // 램프 단계 간격
const unsigned long SESSION_MAX_MS     = 20UL * 60UL * 1000UL; // 최대 세션 20분
const unsigned long OPEN_CIRCUIT_CHECK_MS = 200; // 개방회로 점검 주기

const float SHUNT_OHM            = 10.0;   // 션트 저항값
const float INAMP_GAIN           = 50.0;   // 계측증폭기 게인
const float ADC_VREF             = 3.3;
const int   ADC_RESOLUTION       = 4095;   // 12bit
const int   DAC_RESOLUTION       = 255;    // ESP32 DAC 8bit

// 개방회로(패드 탈락) 판정: 목표 전류 대비 실측 전류가 이 비율 이하로 오래 지속되면 탈락으로 간주
const float OPEN_CIRCUIT_RATIO   = 0.2;
const unsigned long OPEN_CIRCUIT_TOLERANCE_MS = 2000;

// 극성 반전(이벤트 트리거) 판정 파라미터
const float IMPEDANCE_CHANGE_THRESHOLD = 0.15; // 15% 이상 임피던스 변화 시 반전 트리거
const unsigned long MIN_POLARITY_INTERVAL_MS = 5000; // 최소 반전 간격 (너무 잦은 스위칭 방지)
const unsigned long MAX_POLARITY_INTERVAL_MS = 30000; // 변화가 없어도 이 시간 지나면 안전상 반전

// ===================== 상태 변수 =====================
float targetCurrentMA = 0.0;
float measuredCurrentMA = 0.0;
float lastImpedanceOhm = -1.0;
bool  polarityStateA = true; // true: A->B, false: B->A
unsigned long sessionStartMs = 0;
unsigned long lastRampMs = 0;
unsigned long lastPolarityChangeMs = 0;
unsigned long openCircuitStartMs = 0;
bool openCircuitSuspected = false;
bool sessionActive = false;
bool safetyTripped = false;

// ===================== 함수 선언 =====================
void setOutputCurrentTarget(float ma);
float readMeasuredCurrentMA();
void applyDacSetpoint(float ma);
void setPolarity(bool aToB);
void emergencyStop(const char* reason);
void updateRamp();
void checkOpenCircuit();
void checkPolaritySwitch();
void checkSessionTimeout();

void setup() {
  Serial.begin(115200);
  pinMode(PIN_HBRIDGE_IN1, OUTPUT);
  pinMode(PIN_HBRIDGE_IN2, OUTPUT);
  pinMode(PIN_ENABLE_OUTPUT, OUTPUT);
  pinMode(PIN_STATUS_LED, OUTPUT);

  digitalWrite(PIN_ENABLE_OUTPUT, LOW); // 출력 비활성 상태로 시작 (안전)
  setPolarity(true);
  applyDacSetpoint(0.0);

  Serial.println("=== 이온영동기기 프로토타입 부팅 ===");
  Serial.println("경고: 인체 적용 전 반드시 저항 부하로 검증할 것.");
}

void startSession() {
  if (safetyTripped) {
    Serial.println("안전 차단 상태입니다. 재부팅 후 다시 시도하세요.");
    return;
  }
  sessionActive = true;
  sessionStartMs = millis();
  lastRampMs = millis();
  lastPolarityChangeMs = millis();
  targetCurrentMA = START_CURRENT_MA;
  digitalWrite(PIN_ENABLE_OUTPUT, HIGH);
  applyDacSetpoint(targetCurrentMA);
  Serial.println("세션 시작.");
}

void loop() {
  // 시리얼 명령: 's' 시작, 'x' 정지 (테스트용 간단 인터페이스)
  if (Serial.available()) {
    char c = Serial.read();
    if (c == 's') startSession();
    if (c == 'x') emergencyStop("사용자 요청 정지");
  }

  if (!sessionActive || safetyTripped) {
    digitalWrite(PIN_STATUS_LED, safetyTripped ? HIGH : LOW);
    return;
  }

  measuredCurrentMA = readMeasuredCurrentMA();

  // 1. 소프트웨어 상한 체크 (최우선)
  if (measuredCurrentMA > MAX_CURRENT_MA * 1.1) {
    emergencyStop("측정 전류가 소프트웨어 상한을 초과함");
    return;
  }

  // 2. 램프업 처리
  updateRamp();

  // 3. 개방회로(패드 탈락) 감지
  checkOpenCircuit();
  if (safetyTripped) return;

  // 4. 임피던스 기반 이벤트 트리거 극성 반전
  checkPolaritySwitch();

  // 5. 세션 타임아웃
  checkSessionTimeout();

  // 상태 출력 (디버그)
  static unsigned long lastPrint = 0;
  if (millis() - lastPrint > 1000) {
    lastPrint = millis();
    Serial.print("목표(mA): "); Serial.print(targetCurrentMA);
    Serial.print(" 실측(mA): "); Serial.print(measuredCurrentMA);
    Serial.print(" 극성: "); Serial.println(polarityStateA ? "A->B" : "B->A");
  }

  delay(50);
}

void updateRamp() {
  if (targetCurrentMA >= MAX_CURRENT_MA) return;
  if (millis() - lastRampMs >= RAMP_INTERVAL_MS) {
    lastRampMs = millis();
    targetCurrentMA = min(targetCurrentMA + RAMP_STEP_MA, MAX_CURRENT_MA);
    applyDacSetpoint(targetCurrentMA);
  }
}

void checkOpenCircuit() {
  bool suspect = (measuredCurrentMA < targetCurrentMA * OPEN_CIRCUIT_RATIO) && (targetCurrentMA > START_CURRENT_MA);
  if (suspect) {
    if (!openCircuitSuspected) {
      openCircuitSuspected = true;
      openCircuitStartMs = millis();
    } else if (millis() - openCircuitStartMs > OPEN_CIRCUIT_TOLERANCE_MS) {
      emergencyStop("개방회로(패드 탈락) 의심으로 차단");
    }
  } else {
    openCircuitSuspected = false;
  }
}

void checkPolaritySwitch() {
  // 임피던스 = 전압/전류. 여기서는 실측전류와 DAC 설정전압으로 근사 계산.
  float dacVoltage = (targetCurrentMA / 1000.0) * SHUNT_OHM * INAMP_GAIN; // 참고용 근사치
  float impedanceOhm = (measuredCurrentMA > 0.01) ? (dacVoltage / (measuredCurrentMA / 1000.0)) : -1;

  unsigned long sincePolarity = millis() - lastPolarityChangeMs;

  bool changedEnough = false;
  if (lastImpedanceOhm > 0 && impedanceOhm > 0) {
    float change = fabs(impedanceOhm - lastImpedanceOhm) / lastImpedanceOhm;
    changedEnough = (change > IMPEDANCE_CHANGE_THRESHOLD);
  }

  bool timeoutReached = (sincePolarity > MAX_POLARITY_INTERVAL_MS);
  bool minIntervalPassed = (sincePolarity > MIN_POLARITY_INTERVAL_MS);

  if ((changedEnough && minIntervalPassed) || timeoutReached) {
    polarityStateA = !polarityStateA;
    setPolarity(polarityStateA);
    lastPolarityChangeMs = millis();
    Serial.println("[극성 반전] 임피던스 변화 또는 타임아웃 감지");
  }

  if (impedanceOhm > 0) lastImpedanceOhm = impedanceOhm;
}

void checkSessionTimeout() {
  if (millis() - sessionStartMs > SESSION_MAX_MS) {
    emergencyStop("세션 최대 시간(20분) 도달 - 정상 종료");
  }
}

float readMeasuredCurrentMA() {
  int raw = analogRead(PIN_ADC_CURRENT);
  float voltage = (raw / (float)ADC_RESOLUTION) * ADC_VREF;
  float shuntVoltage = voltage / INAMP_GAIN;
  float currentA = shuntVoltage / SHUNT_OHM;
  return currentA * 1000.0; // mA
}

void applyDacSetpoint(float ma) {
  // DAC 출력전압 = (목표전류 * 션트저항) 을 계측증폭 게인 역산하여 기준전압으로 변환
  // 실제 회로 정수는 캘리브레이션 필요
  float targetVoltage = (ma / 1000.0) * SHUNT_OHM; // 션트 양단 목표 전압
  float dacVoltage = targetVoltage; // 오차 보정은 하드웨어 캘리브레이션 후 계수 반영
  int dacValue = constrain((int)((dacVoltage / ADC_VREF) * DAC_RESOLUTION), 0, DAC_RESOLUTION);
  dacWrite(PIN_DAC_SETPOINT, dacValue);
}

void setPolarity(bool aToB) {
  digitalWrite(PIN_HBRIDGE_IN1, aToB ? HIGH : LOW);
  digitalWrite(PIN_HBRIDGE_IN2, aToB ? LOW : HIGH);
}

void emergencyStop(const char* reason) {
  applyDacSetpoint(0.0);
  digitalWrite(PIN_ENABLE_OUTPUT, LOW);
  sessionActive = false;
  safetyTripped = true;
  digitalWrite(PIN_STATUS_LED, HIGH);
  Serial.print("!!! 비상 정지: ");
  Serial.println(reason);
}
